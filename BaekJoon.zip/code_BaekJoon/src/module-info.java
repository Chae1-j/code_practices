/**
 * 
 */
/**
 * 
 */
module code_BaekJoon {
}