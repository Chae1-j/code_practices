package math;

import java.util.Scanner;

public class 진법변환_2745번 {

	public static void main(String[] args) {
		/*
		 * B진법 수 N이 주어진다. 이 수를 10진법으로 바꿔 출력하는 프로그램을 작성하시오.
		 * - 10진법을 넘어가는 진법은 숫자로 표시할 수 없는 자리가 있다. 이런 경우에는 다음과 같이 알파벳 대문자를 사용한다.
		 * 	  A: 10, B: 11, ..., F: 15, ..., Y: 34, Z: 35
		 */
		Scanner sc = new Scanner(System.in);
		String n = sc.next();
	}

}
/* 백준 소스 코드 메뉴얼

import java.util.*;		// Scanner 사용하기 위해서 import해야함

public class Main{
    public static void main(String[] args){
        // Scanner sc = new Scanner(System.in);
	
    }
} 
*/